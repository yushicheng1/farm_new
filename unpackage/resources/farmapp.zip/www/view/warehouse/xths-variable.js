var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		
	},
	btn: {
        btnSubmit:document.getElementById("btn_submit")
	},
	ipt: {
         iptName:document.getElementById("ipt_name"),
		 iptSum:document.getElementById("ipt_sum"),
		 // iptPlant:document.getElementById("ipt_plant"),
		 // iptGet:document.getElementById("ipt_get"),
		 iptPrice:document.getElementById("ipt_price"),
		 iptNum:document.getElementById("ipt_num"),
		 iptImage:document.getElementById("ipt_image")
		 // iptcount:document.getElementById("ipt_count")
	},
	params: {
		vegetablesId:'',
		name:'',
		sum:'',
		plant:'',
		get:'',
		price:'',
		image:'',
		count:'',//鍥炴敹鏁伴噺
	},
};