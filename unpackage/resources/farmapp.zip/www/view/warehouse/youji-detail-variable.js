var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {
         recordList: document.getElementById("record_list")
	},
	btn: {
		
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptUnit: document.getElementById("ipt_unit"),
		iptPhone: document.getElementById("ipt_phone"),
		iptAddress: document.getElementById("ipt_address"),
		iptTotal: document.getElementById("ipt_total")
	},
	params: {
		vegetables:[],
		address:'',
		name:'',
		phone:'',
		order_id:'',
		total:''
	},
};
