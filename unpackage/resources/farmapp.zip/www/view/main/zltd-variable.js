var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		
	},
	btn: {
        
	},
	ipt: {

	}
};