var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnSubtract: document.getElementById("btn_subtract"),
		btnAdd: document.getElementById("btn_add"),
		btnBuy:document.getElementById("btn_buy"),
		btnZs:document.getElementById("btn_zs")
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptImage: document.getElementById("ipt_image"),
		iptStock: document.getElementById("ipt_stock"),
		iptNumber: document.getElementById("ipt_number"),
		iptTotal: document.getElementById("ipt_total"),
		iptPrice: document.getElementById("ipt_price"),
		iptShengzhang: document.getElementById("ipt_shengzhang"),
		iptJieguo: document.getElementById("ipt_jieguo"),
		iptChanliang: document.getElementById("ipt_chanliang"),
		iptPhone: document.getElementById("ipt_phone")
	},
	params: {
		seedId:'',
		seedName:'',
		seedImg:'',
		size:'',
		uniqueId:'',
		shengzhang:'',
		jieguo:'',
		chanliang:'',
		price:0,
		autoPrice:0,
		auto:0,
		phone:0
	}
};
