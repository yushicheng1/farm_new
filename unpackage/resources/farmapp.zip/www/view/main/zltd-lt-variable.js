var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {
		ltList: document.getElementById("lt-list"),
	},
	btn: {
		btnSubtract: document.getElementById("btn_subtract"),
		btnAdd: document.getElementById("btn_add"),
		btnBuy:document.getElementById("btn_buy")
	},
	ipt: {
		iptNumber: document.getElementById("ipt_number"),
		iptTotal: document.getElementById("ipt_total")
	}
};
