var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptIdCard: document.getElementById("ipt-bank"),
		iptNumber: document.getElementById("ipt-number")
	},
	btn: {
		btnSubmit: document.getElementById("btn-submit"),
		btnRecord: document.getElementById("btn-record")
	}
};
