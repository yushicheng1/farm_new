var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		
	},
	btn: {
		btnYhk:document.getElementById("btn_yhk"),
		btnTixian:document.getElementById("btn_tixian"),
		btnRecord:document.getElementById("btn_record"),
		btnTixianBank:document.getElementById("btn_tixian_bank")
	},
	ipt: {
        iptMoney:document.getElementById("ipt_money"),
		iptYue:document.getElementById("ipt_yue")
	}
};