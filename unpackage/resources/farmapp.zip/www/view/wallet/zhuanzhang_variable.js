var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	ipt: {
		iptNumber: document.getElementById("ipt-number")
	},
	btn: {
		
	},
	value: {
		code: true
	}
};
