var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {

	},
	btn: {
        btnSave:document.getElementById("btn_save")
	},
	ipt: {
         iptName:document.getElementById("ipt_name"),
         iptArea:document.getElementById("ipt_area"),
         iptAddress:document.getElementById("ipt_address"),
         iptPhone:document.getElementById("ipt_phone"),
         iptDefault:document.getElementById("ipt_default")
	}
};