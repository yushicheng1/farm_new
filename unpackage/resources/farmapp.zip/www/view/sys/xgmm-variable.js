var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {

	},
	btn: {
		btnSave: document.getElementById("btn_save")
	},
	ipt: {
		iptPassword: document.getElementById("ipt-password"),
		iptPasswordNew: document.getElementById("ipt-password-new"),
		iptPasswordConfirm:document.getElementById("ipt-password-confirm")
	}
};
