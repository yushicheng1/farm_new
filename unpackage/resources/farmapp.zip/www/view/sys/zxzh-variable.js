var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptReason: document.getElementById("ipt-reason"),
		iptPhone: document.getElementById("ipt-phone")
	},
	btn: {
		btnSubmit: document.getElementById("btn-submit")
	},
	params: {		
		isSubmit:true
	}
};
