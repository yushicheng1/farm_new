var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {
		scroll: document.getElementById("box-scroll"),
		logotop: document.getElementById("logotop")
	},
	ipt: {
		iptAccount: document.getElementById("ipt-account"),
		iptCode: document.getElementById("ipt-code"),
		iptImgCode: document.getElementById("ipt-img-code"),
		iptPasswordOne: document.getElementById("ipt-passwordOne"),
		iptPasswordTwo: document.getElementById("ipt-passwordTwo")
	},
	btn: {
		btnEdit:document.getElementById("btn_edit"),
		btnBack:document.getElementById("btn-back"),
		btnCode:document.getElementById("btn-code"),
		btnYzm:document.getElementById("btn_yzm")
	},
	div:{
		
	},
	value:{
		code:true,
		suiji:0
	}
};