var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	ipt:{
		iptName: document.getElementById("ipt_name"),
		iptPhone: document.getElementById("ipt_phone"),
		iptCardNo: document.getElementById("ipt_cardNo"),
		iptYaoqing: document.getElementById("ipt_yaoqing")
	},
	box: {
		scroll: document.getElementById("box-scroll")
	},
	btn: {
		btnBack:document.getElementById("btn_back")
	}
};