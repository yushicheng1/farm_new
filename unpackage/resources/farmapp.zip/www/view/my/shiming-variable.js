var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptIdCard: document.getElementById("ipt-idcard")
	},
	btn: {
		btnSubmit: document.getElementById("btn-submit")
	},
	value: {
		code: true
	}
};
