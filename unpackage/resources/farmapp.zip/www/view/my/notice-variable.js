var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		scroll: document.getElementById("box-scroll"),
		recordList: document.getElementById("record-list")
	},
	btn: {

	},
	ipt: {

	}
};