var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptIdCard: document.getElementById("ipt-idcard"),
		iptBank: document.getElementById("ipt-bank"),
		iptPhone: document.getElementById("ipt-phone")
	},
	btn: {
		btnSubmit: document.getElementById("btn-submit")
	},
	value: {
		code: true
	}
};
