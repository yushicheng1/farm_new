var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnSubtract: document.getElementById("btn_subtract"),
		btnAdd: document.getElementById("btn_add"),
		btnSelectTwo:document.getElementById("select_two"),
		btnPay:document.getElementById("btn_pay"),
		btnChoose: document.getElementById("btn_choose"),
		btnChooseNew: document.getElementById("btn_choose_new")
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptPlant: document.getElementById("ipt_plant"),
		iptStock: document.getElementById("ipt_stock"),
		iptNum: document.getElementById("ipt_num"),
		iptNumber: document.getElementById("ipt_number"),
		iptTotal: document.getElementById("ipt_total"),
		iptPrice: document.getElementById("ipt_price"),
		iptImage: document.getElementById("ipt_image"),
		iptNamePerson: document.getElementById("ipt_name_person"),
		iptPhone: document.getElementById("ipt_phone"),
		iptAddress: document.getElementById("ipt_address"),
		iptYunfei: document.getElementById("ipt_yunfei"),
		iptUnit: document.getElementById("ipt_unit"),
		iptDis: document.getElementById("ipt_discription")
	},
	params: {
		exchange_info_id: '',
		stock:'',
		price:'',
		image:'',
		unit:'',
		dis:''
	}
};
