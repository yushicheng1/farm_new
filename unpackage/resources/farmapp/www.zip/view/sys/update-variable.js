var aVariable = {
	webview: {
		current: null,
	},
	box: {
		
	},
	btn: {
		// btnUpdate : document.getElementById("btn-update"),
		btnService : document.getElementById("service-agreement"),
		btnPrivacy : document.getElementById("privacy-agreement"),
	},
	ipt: {
        phoneNumber : document.getElementById("phone-number")
	}
};