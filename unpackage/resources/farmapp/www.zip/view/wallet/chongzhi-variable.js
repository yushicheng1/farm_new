var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		scroll: document.getElementById("box-scroll")
	},
	btn: {
		btnChongzhi:document.getElementById("btn_chongzhi")
	},
	ipt: {
        iptMoney:document.getElementById("ipt_money"),
	}
};