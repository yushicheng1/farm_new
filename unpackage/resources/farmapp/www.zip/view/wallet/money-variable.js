var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		
	},
	btn: {
		btnYhk:document.getElementById("btn_yhk"),
		btnTixian:document.getElementById("btn_tixian"),
		btnRecord:document.getElementById("btn_record")
	},
	ipt: {
        iptMoney:document.getElementById("ipt_money"),
		iptYue:document.getElementById("ipt_yue")
	}
};