var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnAllOrder:document.getElementById("all_order"),
		btnDfk:document.getElementById("btn-dfk"),
		btnYfk:document.getElementById("btn-yfk"),
		btnwdjf:document.getElementById("btn-wdjf"),
		btnwdqb:document.getElementById("btn-wdqb"),
		btnWddz:document.getElementById("btn-wddz"),
		btnYjdj:document.getElementById("btn-yjdj"),
		btnYjfk:document.getElementById("btn-yjfk"),
		btnBbsj:document.getElementById("btn-bbsj"),
		// btnBzzx:document.getElementById("btn-bzzx"),
		btnKfzx:document.getElementById("btn-kfzx"),
		btnZxdl:document.getElementById("btn-zxdl"),
		btnXgmm:document.getElementById("btn-xgmm"),
		btnWdjy:document.getElementById("btn-wdjy"),
		btnXtsj:document.getElementById("btn-xtsj"),
		btnWdyhk:document.getElementById("btn-wdyhk"),
		btnDzxy:document.getElementById("btn-dzxy"),
		btnZzmx:document.getElementById("btn-zzmx"),
		btnBdsjh:document.getElementById("btn-bdsjh")
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptImage:document.getElementById("ipt-img"),
		iptJifen:document.getElementById("ipt-jifen"),
		iptYue:document.getElementById("ipt-yue")
	},
	params: {
		noticeId: '',
		token:''
	}
};