var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnSubtract: document.getElementById("btn_subtract"),
		btnAdd: document.getElementById("btn_add"),
		btnSelectTwo:document.getElementById("select_two"),
		btnPay:document.getElementById("btn-pay")
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptPlant: document.getElementById("ipt_plant"),
		iptGet: document.getElementById("ipt_get"),
		iptNum: document.getElementById("ipt_num"),
		iptNumber: document.getElementById("ipt_number"),
		iptTotal: document.getElementById("ipt_total"),
		iptPrice: document.getElementById("ipt_price"),
		iptImage: document.getElementById("ipt_image")
	},
	params: {
		exchange_info_id: '',
		plantTime:'',
		getTime:'',
		num:'',
		price:'',
		image:''
	}
};
