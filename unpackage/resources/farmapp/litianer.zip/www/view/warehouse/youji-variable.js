var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {

	},
	btn: {
		btnChoose: document.getElementById("btn_choose"),
		btnChooseNew: document.getElementById("btn_choose_new"),
		btnYouji: document.getElementById("btn_youji")
	},
	ipt: {
		iptPlantName: document.getElementById("ipt_plant_name"),
		iptPlant: document.getElementById("ipt_plant"),
		iptGet: document.getElementById("ipt_get"),
		iptSum: document.getElementById("ipt_sum"),
		iptNum: document.getElementById("ipt_num"),
		iptName: document.getElementById("ipt_name"),
		iptPhone: document.getElementById("ipt_phone"),
		iptAddress: document.getElementById("ipt_address"),
		iptImage: document.getElementById("ipt_image")
	},
	params: {
		vegetablesId:'',
		addressId:'',
		name:'',
		sum:'',
		plant:'',
		get:'',
		image:''
	},
};
