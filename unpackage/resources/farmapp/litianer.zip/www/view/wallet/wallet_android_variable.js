var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		moneyList: document.getElementById("chongzhi-list")
	},
	btn: {
        btnPay:document.getElementById("btn_pay")
	},
	ipt: {
        iptMoney:document.getElementById("ipt_money"),
		iptJiFen:document.getElementById("ipt_jifen")
	},
	params:{
		apple_id:''
	}
};