var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnAllOrder:document.getElementById("all_order"),
		btnDfk:document.getElementById("btn-dfk"),
		btnYfk:document.getElementById("btn-yfk"),
		btnwdjf:document.getElementById("btn-wdjf"),
		btnwdqb:document.getElementById("btn-wdqb"),
		btnWddz:document.getElementById("btn-wddz"),
		btnYjdj:document.getElementById("btn-yjdj"),
		btnYjfk:document.getElementById("btn-yjfk"),
		btnBbsj:document.getElementById("btn-bbsj"),
		btnBzzx:document.getElementById("btn-bzzx"),
		btnKfzx:document.getElementById("btn-kfzx"),
		btnZxdl:document.getElementById("btn-zxdl"),
		btnXgmm:document.getElementById("btn-xgmm"),
		btnWdjy:document.getElementById("btn-wdjy")
		// btnName:document.getElementById("btn-name"),
		// btnPhone:document.getElementById("btn-phone")
	},
	ipt: {
		iptName: document.getElementById("ipt-name"),
		iptPhone: document.getElementById("ipt-phone"),
		iptImage:document.getElementById("ipt_image")
	},
	params: {
		noticeId: ''
	}
};