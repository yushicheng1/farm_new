var aVariable = {
	webview: {
		current: null,
		listComponent: null
	},
	box: {

	},
	btn: {
		btnSave: document.getElementById("btn_save"),
		btnImg:document.getElementById("user_img")
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptPhone: document.getElementById("ipt_phone"),
		iptImg:document.getElementById("ipt_img")
	},
	params: {
       name:'',
	   phone:'',
	   avatar:''
	}
};
