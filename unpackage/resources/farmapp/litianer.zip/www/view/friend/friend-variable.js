var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {

	},
	btn: {
        btnFindFriend:document.getElementById("btn_find_friend")
	},
	ipt: {
        
	},
	params:{
		
	}
};