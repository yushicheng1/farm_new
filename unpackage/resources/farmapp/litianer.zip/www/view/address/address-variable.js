var aVariable = {
	webview: {
		current: null,
		listComponent : null
	},
	box: {
		scroll: document.getElementById("box-scroll"),
		addressList: document.getElementById("address-list"),
		sliderImg: document.getElementById("sliderImg"), //应用页面滚动图片
		sliderIndicator: document.getElementById("sliderIndicator") //滚动点
	},
	btn: {
        btnNewAdress:document.getElementById("new_address")
	},
	ipt: {

	}
};