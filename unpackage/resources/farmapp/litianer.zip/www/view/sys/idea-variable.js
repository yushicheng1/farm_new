var aVariable = {
	webview: {
		current: null,
	},
	box: {
		
	},
	btn: {
		btnSubmit : document.getElementById("btn_submit")
	},
	ipt: {
        iptContent : document.getElementById("ipt_content")
	}
};