var aVariable = {
	webview: {
		current: null,
	},
	box: {
		
	},
	btn: {
		btnUpdate : document.getElementById("btn-update")
	},
	ipt: {
        
	}
};