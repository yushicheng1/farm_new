var aVariable = {
	webview: {
		current: null,
	},
	box: {
         sliderImg:document.getElementById("slider_img")
	},
	btn: {
        btnWdnc:document.getElementById("btn_wdnc"),
		btnGmzz:document.getElementById("btn_gmzz"),
		btnJydt:document.getElementById("btn_jydt"),
		btnTgm:document.getElementById("btn_tgm")
	},
	ipt: {
		iptHeader: document.getElementById("ipt-header"),
		iptTitle: document.getElementById("ipt-title"),
		iptName: document.getElementById("ipt-name"),
		iptTime: document.getElementById("ipt-time"),
		iptNum: document.getElementById("ipt-num"),
		iptContent: document.getElementById("ipt-content")
	},
	div:{
		divRt:document.getElementById("div_rt")
	},
	params: {
		noticeId: ''
	}
};