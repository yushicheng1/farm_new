var aVariable = {
	webview: {
		current: null,
	},
	box: {

	},
	btn: {
		btnSubtract: document.getElementById("btn_subtract"),
		btnAdd: document.getElementById("btn_add"),
		btnBuy:document.getElementById("btn_buy")
	},
	ipt: {
		iptName: document.getElementById("ipt_name"),
		iptImage: document.getElementById("ipt_image"),
		iptStock: document.getElementById("ipt_stock"),
		iptNumber: document.getElementById("ipt_number"),
		iptTotal: document.getElementById("ipt_total"),
		iptPrice: document.getElementById("ipt_price")
	},
	params: {
		seedId:'',
		seedName:'',
		seedImg:'',
		size:'',
		uniqueId:''
	}
};
